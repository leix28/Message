package com.ihs.message_2013011344.managers;

public class ReceiptManager {

}
