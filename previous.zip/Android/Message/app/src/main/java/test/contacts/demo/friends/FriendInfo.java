package test.contacts.demo.friends;

public class FriendInfo {

    public String sid;
    public String mid;
    public String verifyType;
    public String accountType;
}
